/**
 * File Name: mainscript.js
 * Description: Main javascript code for overall website
 * @author: Analia Mok
 */

// Execute initialization code on load
// Mainly for preloading images and executing slideshow
window.onload = init;


/**
 * init - Preloads images depending on current page
 *      Executes slide show if slide show is present in DOM
 *
 */
function init(){

    if(document.getElementById("slideshow")){
        // If present, start slideshow animation
        slideshow();
    }
    
    // Give up button an onclick event
    document.getElementsByClassName("up_btn")[0]
        .onclick= function(){
            window.scrollTo(0, 0);
        }
} // End of init


/**
 * slideshow - Animation that displays and undisplays
 * images in a container div
 */

var slideIndex = 0; // Global Slide Counter
function slideshow(){

    var slides = document.getElementsByClassName("slide");
    var totalSlides = slides.length;

    for(var i = 0; i < totalSlides; i++){
        // Start by hiding all slides
        slides[i].style.display = "none";
    }

    slideIndex = (slideIndex % totalSlides) + 1;
    slides[slideIndex-1].style.display = "block";

    // Change the text inside the caption
    var captionSpan = document.getElementById("caption");
    captionSpan.innerHTML = "";
    if(slides[slideIndex-1].id === "disney_castle"){
        captionSpan.innerHTML = "(Magic 2017)";
    }else{
        captionSpan.innerHTML = "(i.ytimg.com)";
    }
    
    // Need to display
    captionSpan.style.display = "block";
    
    // Change images every 3.5s
    setTimeout(slideshow, 7000);
} // End of slideshow


/**
 * openMenu - Function that reveals the hidden navigation
 * items in views that have a width smaller than the full desktop nav
 */
function openMenu(){

    // The top level ul in the main navigation
    var topNav = document.getElementById("top_level_nav");

    // All list items in the ul
    var listItems = topNav.getElementsByTagName("li");

    // length of list
    var length = listItems.length;

    // Toggle the display of list items
    for(var i = 1; i < length; i++){
        var currItem = listItems[i];

        if(currItem.className === ""){
            // If no class added, add "responsive" class
            currItem.className = "responsive";
        }else{
            currItem.className = "";
        }

    }

    // Change Menu Button Text
    var menuBtn = document.getElementById("menu_btn");
    if(menuBtn.innerHTML === "Open"){
        menuBtn.innerHTML = "Close";
    }else{
        menuBtn.innerHTML = "Open";
    }

} // End of openMenu
